export interface Profesores {
    mote: string,
    correo: string,
    password: string,
    nombre: string,
    apellidos: string,
    centro: string
}