export interface Login {
    mote: string,
    password: string,
}