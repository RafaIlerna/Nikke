export interface Alumnos {
  mote: string,
  correo: string,
  password: string,
  nombre: string,
  apellidos: string,
  date: string
}