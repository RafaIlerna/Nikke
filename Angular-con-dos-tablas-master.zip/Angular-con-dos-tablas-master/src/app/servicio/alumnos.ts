export interface Alumnos {
    id?: string,
    mote: string,
    correo: string
}
